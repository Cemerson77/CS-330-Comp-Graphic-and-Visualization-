//
//Christine Emerson
//CS-330 Computer Graphics and Visualization
//2-3 Assignment: 2D Triangles
//


#include <GLFW/glfw3.h> // Include the GLFW library header for window and context management
#include <iostream> // Include the standard input/output stream library

//Defining screen width and height
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

//main function
int main(void)
{
	// Declaration of a pointer to a GLFWwindow object
	GLFWwindow* window;

	// If GLFW initialization fails
	if (!glfwInit())
	{
	// Return -1 as an error code
	return -1;
	}
	
	// Create a window with specified dimensions and title(my name)
	window = glfwCreateWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Christine Emerson", NULL, NULL);
	
	int screenWidth, screenHeight;
	glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

	// Check if window creation failed
	if (!window)
	{
		// Terminate GLFW and return an error code
		glfwTerminate();
		return -1;
	}

	// Set the current context to the newly created window
	glfwMakeContextCurrent(window);

	// Set the viewport to match the window size
	glViewport(0.0f, 0.0f,screenWidth,screenHeight); 
	// Set the current matrix mode to projection
	glMatrixMode(GL_PROJECTION); 
	// Load the identity matrix for the projection matrix
	glLoadIdentity(); 
	// Set up an orthographic projection matrix
	glOrtho(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, 0, 600); 
	// Set the current matrix mode to modelview
	glMatrixMode(GL_MODELVIEW);
	// Load the identity matrix for the modelview matrix
	glLoadIdentity(); 

	// Define vertices for the first triangle
	GLfloat v[9] = {
		270,290,0,
		270,190,0,
		370,190,0
	};

	// Define vertices for the second triangle
	GLfloat v2[10] = {
		370 + 100,90,0,
		370 + 100,190,0,
		270 + 100,190,0
	};
	
	// Define colors for the triangles
	GLfloat colour[] =
	{
		255,0,0,
		0, 255,0,
		0,0,255
	};

	//Loop until the user closes the window
	while (!glfwWindowShouldClose(window))
	{
		// Clear the color buffer to ensure that the next frame starts with a clean slate, free of any previous rendered content.
		glClear(GL_COLOR_BUFFER_BIT);

		//Render OpenGL here
		glEnableClientState(GL_VERTEX_ARRAY); // Enable the use of vertex array data
		glEnableClientState(GL_COLOR_ARRAY); // Enable the use of color array data

		// Set the pointer to the vertex array and draw the first triangle
		glVertexPointer(3, GL_FLOAT, 0, v); 
		glColorPointer(3, GL_FLOAT, 0, colour); 
		glDrawArrays(GL_TRIANGLES, 0, 3); 

		// Set the pointer to the vertex array and draw the second triangle
		glVertexPointer(3, GL_FLOAT, 0, v2); 
		glColorPointer(3, GL_FLOAT, 0, colour);
		glDrawArrays(GL_TRIANGLES, 0, 3); 

		glDisableClientState(GL_COLOR_ARRAY); // Disable the use of color array attribute
		glDisableClientState(GL_VERTEX_ARRAY); // Disable the use of vertex array attribute

		//Swap front and back buffers of the window
		glfwSwapBuffers(window);

		//Poll for and process events
		glfwPollEvents();
	}

	// Clean up and terminate GLFW
	glfwTerminate();

	return 0;
}

